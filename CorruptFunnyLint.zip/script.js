// Função para enviar os dados do formulário para o Apps Script
document.querySelector('.enviar-button').addEventListener('click', function() {
    // Obtendo os valores das bibliografias
    var bibliografiaBasica1 = document.querySelector('textarea[placeholder="Escreva aqui sobre a bibliografia básica..."]:nth-of-type(1)').value;
    var bibliografiaBasica2 = document.querySelector('textarea[placeholder="Escreva aqui sobre a bibliografia básica..."]:nth-of-type(2)').value;
    var bibliografiaBasica3 = document.querySelector('textarea[placeholder="Escreva aqui sobre a bibliografia básica..."]:nth-of-type(3)').value;

    var bibliografiaComplementar1 = document.querySelector('textarea[placeholder="Escreva aqui sobre a bibliografia complementar..."]:nth-of-type(1)').value;
    var bibliografiaComplementar2 = document.querySelector('textarea[placeholder="Escreva aqui sobre a bibliografia complementar..."]:nth-of-type(2)').value;
    var bibliografiaComplementar3 = document.querySelector('textarea[placeholder="Escreva aqui sobre a bibliografia complementar..."]:nth-of-type(3)').value;

    // Enviando os dados para o Google Apps Script via fetch
    fetch('https://script.google.com/macros/s/AKfycbzoTaPhTKifTRa06qeVjSI77dQQiNiHF1uxFZMAqnl1skgJ5mtaQao61J9kgAqZrDKdrg/exec', {
        method: 'POST',
        body: new URLSearchParams({
            'bibliografia_basica1': bibliografiaBasica1,
            'bibliografia_basica2': bibliografiaBasica2,
            'bibliografia_basica3': bibliografiaBasica3,
            'bibliografia_complementar1': bibliografiaComplementar1,
            'bibliografia_complementar2': bibliografiaComplementar2,
            'bibliografia_complementar3': bibliografiaComplementar3
        })
    })
    .then(response => response.text())
    .then(data => {
        if (data === 'success') {
            alert('Dados enviados com sucesso!');
        } else {
            alert('Houve um erro ao enviar os dados!');
        }
    })
    .catch(error => {
        console.error('Erro ao enviar os dados:', error);
        alert('Erro ao enviar os dados!');
    });
});
